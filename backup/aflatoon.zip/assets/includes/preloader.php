<div id="preloader">
   <div class="middle d_sm_none ">
	  <ul class="move">
		 <li >A</li>
		 <li >F</li>
		 <li >L</li>
		 <li >A</li>
		 <li >T</li>
		 <li class="parent">
			<div class="eye">
			   <img src="assets/images/7.png" class="eyebrow">
			   <div class="eyes">
				  o
				  <div class="dot dotmove"></div>
			   </div>
			</div>
		 </li>
		 <li class="parent">
			<div class="eye">
			   <img src="assets/images/8-1.png" class="eyebrow top4">
			   <div class="eyes">
				  o
				  <div class="dot dotmove"></div>
			   </div>
			</div>
		 </li>
		 <!-- <li><span class="eyes"></span></li> -->
		 <li>N</li>
	  </ul>
	  <span class="font-gotham font-20px text-black letter animated fadeIn delay-3s">DESIGNS</span>
   </div>
   <div class="mobpreloader middle d_sm_block d_md_none">
	  <img src="assets/images/logo/logo.png">
   </div>
</div>